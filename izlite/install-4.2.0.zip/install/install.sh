#!/bin/bash
# 
#================================================
#  Installeur IZLite pour Linux
#===============================================
# Pr�-requis : avoir install� libRXTX sur le syst�me
#
# Usage :
# se positionner dans le repertoire prj_izlite/install_linux
# sudo  ./install.sh
#===============================================

# Version du script d'instalation
INSTALLERVERSION="i364d"

# Positionne la variable IZLITEVERSION qui contient le numero de verison installee
source ./installVersion.sh

# check si IZLITEVERSION est renseigne
if [[ -z "$IZLITEVERSION" ]]; then
    echo "ECHEC : Numero de version non renseigne dans installVersion.sh"
    exit 8
fi

# ----- check du paquet de livraison ----------
# le repertoire parent doit commencer par "prj_izlite" 
cd ..
PW=`pwd`
PRJDIR=`basename $PW`
if [[ "${PRJDIR:0:10}" == "prj_izlite" ]]; then
    echo "Livraison conforme"
else
 echo "Livraison non conforme : installation impossible (prj_izlite absent)"
 exit 15
fi

# repertoire de destination des versions, terminer par un slash
DEST="/opt/"
APPLICATION="izlite"

echo " "
echo "Installation  IZLite  version $IZLITEVERSION"
echo "Analyse de l'existant..."

# ------- check de la destination ----------

# construit le nom du nouveau repertoire d'install
NEWVERSION="izlite${IZLITEVERSION}"
# construit le chemin complet
NEWCHEMIN="${DEST}${NEWVERSION}/"

echo "Checking destination ${NEWCHEMIN}"
# recherche repertoire application dans /opt
ls  -d  ${NEWCHEMIN}  2> /dev/null
NEWEXIST=$?
if [ "$NEWEXIST" = "0" ]; then
    echo "Version $NEWVERSION deja presente dans $DEST  => ARRET"
	exit 16
else
 echo "Version $NEWVERSION pas encore installee"
fi

# ---------- verifie presence de java ----------------

java -version
JRE=$?
if [ "$JRE" = "0" ]; then
    echo "Java est disponible"
else
 echo "INSTALLER JAVA"
 exit 43
fi

# ------- verifie presence de librxtx -----------

dpkg -l | grep librxtx
RXTX=$?
if [ "$RXTX" = "0" ]; then
    echo "Bibliotheque librxtx disponible"
else
 echo "Bibliotheque librxtx non disponible => A INSTALLER"
 exit 44
fi

            
# ------- verifie droit ecriture dans $DEST ------------
CHKWRT="${DEST}izlite_chk_wrt_${RANDOM}"
mkdir $CHKWRT
CREATION=$?
if [ "$CREATION" = "0" ]; then
    echo "Ecriture autorisee dans $DEST"
	rmdir $CHKWRT
else
 echo "ECRITURE IMPOSSIBLE dans $DEST   (utiliser sudo ?)"
 exit 17
fi


read -p "Pret a installer, faire ENTREE pour poursuivre,  CTRL-C pour arreter =>"


cd ..
echo "Installation debute pwd= $PWD"
echo "Installation de $PRJDIR"
echo "           dans $NEWCHEMIN"

# ------- copie de la matiere logicielle ------------------

cp -R $PRJDIR $NEWCHEMIN
COPIE1=$?
if [ "$COPIE1" = "0" ]; then
    echo "Copie du projet Java  OK" 
else
 echo "Copie du projet Java impossible de $PRJDIR dans $DEST"
 exit 20
fi

# ------- copie du script de boot IHM ------------------

cp $PRJDIR/install_linux/izliteboot.sh  $NEWCHEMIN
COPIE2=$?
if [ "$COPIE2" = "0" ]; then
    echo "Copie du script izliteboot.sh OK"
else
 echo "Copie izliteboot.sh impossible de $PRJDIR dans $DEST"
 exit 21
fi

# ------- copie du script de boot deporte ------------------

cp $PRJDIR/install_linux/izldeport.sh  $NEWCHEMIN
COPIE2=$?
if [ "$COPIE2" = "0" ]; then
    echo "Copie du script izldeport.sh OK"
else
 echo "Copie izldeport.sh impossible de $PRJDIR dans $DEST"
 exit 21
fi

# -------- autorisation d'execution -------------

chmod -R +rx $NEWCHEMIN

# -------- mise a dispo modele de config log4j --------------

SRCL4J1=$PRJDIR/src/org/izeaux/izlite/util/iz_log4j.xml
DSTL4J1=$NEWCHEMIN/data/iz_log4j.xml
cp $SRCL4J1  $DSTL4J1
COPIE_LOG4J=$?
if [ "$COPIE_LOG4J" = "0" ]; then
    echo "Configuration log4j exemple dans $DSTL4J1"
else
 echo "Copie iz_log4j.xml impossible de $SRCL4J1 vers $DSTL4J1 "
 exit 22
fi

# --------- Install de la base des fixtures -------------------

echo "Installation des fixtures QLC dans $NEWCHEMIN/data/"
cp $PRJDIR/data/fixturesQLC.zip  $NEWCHEMIN/data/
COPIE_FIXQLC=$?
if [ "$COPIE_FIXQLC" = "0" ]; then
    echo "Fixtures QLC OK"
else
 echo "Installation des fixtures QLC impossible de $PRJDIR/data/fixturesQLC.zip vers $NEWCHEMIN/data/"
 exit 23
fi

echo "Installation des fixtures User dans $NEWCHEMIN/data/"
cp $PRJDIR/data/fixturesUSER.zip  $NEWCHEMIN/data/
COPIE_FIXUSER=$?
if [ "$COPIE_FIXUSER" = "0" ]; then
    echo "Fixtures User OK"
else
 echo "Installation des fixtures User impossible de $PRJDIR/data/fixturesUSER.zip vers $NEWCHEMIN/data/"
 exit 24
fi

# ---------- et on fait pointer /opt/izlite vers cette nouvelle version

cd $DEST

if [ -L $LK ]; then
   echo "Suppression de l'ancien lien symbolique"
   rm izlite
fi

echo "Creation du lien symbolique ${DEST}izlite pointant sur $NEWVERSION"

ln -s $NEWVERSION izlite

alias izlite="${DEST}/izlite/izliteboot.sh"

echo "Installation terminee"

