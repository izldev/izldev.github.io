#!/bin/bash

#================================================
# Demarrage Izlite deporte
#================================================
# Parametre facultatif : le repertoire ou se situe la configuration deportee
#================================================
# 

echo "izldeport.sh : instance Izlite deportee"

if [ -z "$1" ]
  then
    DIRW=`pwd`
    echo "Pas de parametre fourni, repertoire de travail = pwd = $DIRW"
else
    DIRW=$1
    echo "Parametre fourni, repertoire de travail = $DIRW"
fi

FICPROP=${DIRW}/izliteDeporte.properties

echo "recherche du fichier $FICPROP"

if [ -f "$FICPROP" ]; then
   echo "trouve"
else
   echo "Fichier non trouve : $FICPROP"
   exit 12
fi
   

APP="/opt/izlite/"
EXEC_JAVA="java "

CLP="${APP}/bin:${APP}/lib/jargs.jar:${APP}/lib/log4j-1.2.17.jar:${APP}/lib/jdom-2.0.5.jar:${APP}/lib/RXTXcomm22pre1.jar:${APP}/lib/jetty-izl-9.4.6.jar"

${EXEC_JAVA} -cp $CLP org.izeaux.izlite.lanceur.Lanceur --deport_config $DIRW



