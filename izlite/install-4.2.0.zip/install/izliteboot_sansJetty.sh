

APP="/opt/izlite/"
EXEC_JAVA="java "

#================================================
# Demarrage Izlite sur Linux - b340 du 19/08/2016
#===============================================
# Pr�-requis : avoir install� libRXTX sur le syst�me
#===============================================

dmesg  | grep  'now attached'
chmod ugo+rw /dev/ttyUSB0
if [ $? -eq 0 ];
then
    echo Boitier ENTTEC detecte
else
    echo Pas trouve le boitier ENTTEC sur ttyUSB0 !
fi

cd ${DATADIR}

# ancienne librairie  CLP="${APP}/bin:${APP}/lib/jargs.jar:${APP}/lib/log4j-1.2.15.jar:${APP}/lib/jdom-1.1.3.jar:${APP}/lib/RXTXcomm217.jar"
CLP="${APP}/bin:${APP}/lib/jargs.jar:${APP}/lib/log4j-1.2.17.jar:${APP}/lib/jdom-2.0.5.jar:${APP}/lib/RXTXcomm22pre1.jar"

${EXEC_JAVA} -cp $CLP org.izeaux.izlite.lanceur.Lanceur --debug --home ${HOME}  


