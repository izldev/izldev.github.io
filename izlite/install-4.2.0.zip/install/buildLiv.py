#!/usr/bin/python3
# coding: utf-8

#-------------------------------------------------------------------
# Construction d'un paquet d'install Izlite � partir du workspace
#
# On cr�e un zip qui ne contient que le projet Eclipse,
# en sacrifiant les metadata et l'historique Mercurial.

# Le paquet est nomm� avec la date de creation et le numero de version Izlite.
# Le numero de version est extrait de la constante GVERSION de la classe Lanceur.java
#-------------------------------------------------------------------

import os
import re
import sys
import zipfile
from datetime import date
import tempfile
import shutil

#--------------------------------------------------------------
# zipdir : fonction pour zipper un repertoire 'en profondeur'
#--------------------------------------------------------------
def zipdir(path, ziph):
    # ziph is zipfile handle
    for root, dirs, files in os.walk(path):
        for file in files:
            ziph.write(os.path.join(root, file))

			
			
#----------------------------#
#  * * *   M A I N   * * *   #
#----------------------------#
if __name__ == '__main__':

    builderversion="1.0.3"
    print(" ")
    print("**** Izlite Builder version ",builderversion)
    
    tmpdir=tempfile.TemporaryDirectory(prefix='IzlBuild_').name
    print('created temporary directory', tmpdir)
    
    
    cwd = os.getcwd()
    print("Repertoire courant : ", cwd)
    
    tmp=os.path.join(cwd,"..")
    prjdir=os.path.realpath(tmp)
    print("Repertoire prj : ", prjdir)
    
    tmp=os.path.join(cwd,"../..")
    depodir=os.path.realpath(tmp)
    print("Repertoire depot : ", depodir)
    
    
    lanceur=os.path.join(depodir,'prj_izlite/src/org/izeaux/izlite/lanceur/Lanceur.java')

    print("Lanceur : ", lanceur)
    
	# on extrait le numero de version dans la ligne-type ci-dessous
	
    #       private static String GVERSION = "3.5.7b du 22/08/2017 14:34";
    
    lincod=''
    versio='x'
    with open(lanceur,'r') as fin:
        for line in fin:
            if 'GVERSION' in line:
                if 'public static String' in line:
                    print( line )
                    lincod=line
                    p1=lincod.find('"')
                    print("p1=",p1)
                    p2=lincod.find(' ',p1)
                    print("p2=",p2)
                    versio=lincod[p1+1:p2]     # extraction de la sous-chaine
                    print("version=>"+versio+'<')
                    
#--------------------------------------------------------------
# demande de confirmation 
#--------------------------------------------------------------
                
    message="Fabriquer la livraison "+versio+" (O/N) ? "
    reponse = input(message)
    reponse=reponse.upper()
    print("reponse=",reponse)
    if reponse == "O" :
        print("go")
    else:
        print("Arret")
        sys.exit(12)
    	
#--------------------------------------------------------------
# generation du script installversion.sh 
#  qui contient une ligne :  export IZLITEVERSION=x.y.z
#--------------------------------------------------------------
    scriptExport=depodir+'/prj_izlite/install_linux/installVersion.sh'
    with open(scriptExport, "w") as text_file:
        print("export IZLITEVERSION={}".format(versio), file=text_file, end='')

#--------------------------------------------------------------
# generation du script installversion.cmd 
#  qui contient une ligne :  SET IZLITEVERSION=x.y.z
#--------------------------------------------------------------
    scriptExport=depodir+'/prj_izlite/install_linux/installVersion.cmd'
    with open(scriptExport, "w") as text_file:
        print("Set IZLITEVERSION={}".format(versio), file=text_file, end='')
		
#--------------------------------------------------------------
# Fabrication du zip
#--------------------------------------------------------------

#  le repertoire racine du zip (prj) est suffix� par le numero de version

    niouprj="prj_izlite_"+versio
    tmpprj=os.path.join(tmpdir,niouprj)
    print("copie de   "+prjdir)
    print("      vers "+tmpprj)
    shutil.copytree(prjdir,tmpprj)
     
    os.chdir(tmpdir)
    
    print("Projet livre :"+niouprj)
    zipName = os.path.join(depodir,"IzliteInstall_"+date.today().strftime("%Y%m%d")+"_v"+versio+".zip")
    print("Construction de la livraison en cours...   "+zipName)
    zipf = zipfile.ZipFile(zipName, 'w', zipfile.ZIP_DEFLATED)
    
    
    zipdir(niouprj, zipf)
    zipf.close()
    print(" ")
    item = input("Termine.  Tapez Entree.")
	
