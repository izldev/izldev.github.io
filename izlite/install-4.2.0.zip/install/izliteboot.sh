

APP="/opt/izlite/"
EXEC_JAVA="java "

#================================================
# Demarrage Izlite sur Linux - 357b_bas du 21/09/2017
# Ajout des bibliotheques Jetty 9.4.6
#===============================================
# Pre-requis au choix : avoir installe sur le systeme
#     libRXTX    : sudo apt install librxtx-java
#  ou libJSSC    : sudo apt install libjssc-java
#===============================================

dmesg  | grep  'now attached'
chmod ugo+rw /dev/ttyUSB0
if [ $? -eq 0 ];
then
    echo Boitier ENTTEC detecte
else
    echo Pas trouve le boitier ENTTEC sur ttyUSB0 !
fi

echo "PATH=$PATH"

# verifie presence des bibliotheques de comm série
ISRXTX=$( dpkg -l 'librxtx-java' )
echo "ISRXTX=$ISRXTX"
if [[ -z "$ISRXTX" ]]; then
  echo "librxtx non installee "
else
  echo "librxtx installee"
fi

ISJSSC=$( dpkg -l 'libjssc-java' )
echo "ISJSSC=$ISJSSC"
if [[ -z "$ISJSSC" ]]; then
  echo "libjssc non installee "
else
  echo "libjssc installee"
fi

cd ${DATADIR}

# ancienne librairie  CLP="${APP}/bin:${APP}/lib/jargs.jar:${APP}/lib/log4j-1.2.15.jar:${APP}/lib/jdom-1.1.3.jar:${APP}/lib/RXTXcomm217.jar"
CLP="${APP}/bin:${APP}/lib/jargs.jar:${APP}/lib/log4j-1.2.17.jar:${APP}/lib/jdom-2.0.5.jar"
CLP="${CLP}:${APP}/lib/RXTXcomm22pre1.jar"
CLP="${CLP}:${APP}/lib/jssc-2.9.7-SNAPSHOT-linux-x86_64-64.jar"
CLP="${CLP}:${APP}/lib/jetty-izl-9.4.6.jar"

${EXEC_JAVA} -cp $CLP org.izeaux.izlite.lanceur.Lanceur --debug --home ${HOME}  

