#!/bin/bash
# 
#================================================
#  Installeur IZLite pour Linux
#===============================================
# Pr�-requis : avoir install� libRXTX sur le syst�me
#
# Usage :
# se positionner dans le repertoire prj_izlite/install_linux
# sudo  ./install.sh
#===============================================

# Version du script d'instalation
INSTALLERVERSION="i420a"

# repertoire de destination des versions, sans terminer par un slash
DEST="/opt"

# nom du lien symbolique dans /opt
APPLICATION="izlite"

# Positionne la variable IZLITEVERSION qui contient le numero de version installee
export IZLITEVERSION=4.2.0

# check si IZLITEVERSION est renseigne
if [[ -z "$IZLITEVERSION" ]]; then
    echo "ECHEC : Numero de version non renseigne "
    exit 8
fi


# ----- check du paquet de livraison ----------
# le fichier doit se nommer  izlite-x.y.z-jar-with-dependencies.jar

BIGJARNAME="izlite-${IZLITEVERSION}-jar-with-dependencies.jar"
if [ -f  ./target/${BIGJARNAME} ]; then
  echo "le fichier  ${BIGJARNAME} est pret"
else
  echo " "
  echo "il manque le fichier  ${BIGJARNAME}  dans le repertoire ./target"
  echo "Abandon"
  exit 12
fi



echo " "
echo "Installation IZLite  version $IZLITEVERSION"
echo "Analyse de l'existant..."

# ------- check de la destination ----------

# construit le nom du nouveau repertoire d'install
NEWVERSION="izlite${IZLITEVERSION}"
# construit le chemin complet
NEWCHEMIN="${DEST}/${NEWVERSION}"

echo "Checking destination ${NEWCHEMIN}"
# recherche repertoire application dans /opt
ls  -d  ${NEWCHEMIN}  2> /dev/null
NEWEXIST=$?
if [ "$NEWEXIST" = "0" ]; then
    echo "Version $NEWVERSION deja presente dans $DEST  => ARRET"
    echo "Pour faire le menage   :   sudo rm -R ${NEWCHEMIN}"
	exit 16
else
 echo "OK, version $NEWVERSION pas encore installee"
fi

# ---------- verifie presence de java ----------------

java -version
JRE=$?
if [ "$JRE" = "0" ]; then
    echo "Java est disponible"
else
 echo "INSTALLER JAVA"
 exit 43
fi

# ------- verifie presence de librxtx -----------

dpkg -l | grep librxtx
RXTX=$?
if [ "$RXTX" = "0" ]; then
    echo "Bibliotheque librxtx disponible"
else
 echo "Bibliotheque librxtx NON DISPONIBLE => A installer par    sudo apt install librxtx-java "
 exit 44
fi

            
# ------- verifie droit ecriture dans $DEST ------------
CHKWRT="${DEST}/izlite_check_write_access_${RANDOM}"
mkdir $CHKWRT
CREATION=$?
if [ "$CREATION" = "0" ]; then
    echo "Ecriture autorisee dans $DEST"
	rmdir $CHKWRT
else
 echo "ECRITURE IMPOSSIBLE dans $DEST   (utiliser sudo ?)"
 exit 17
fi


read -p "Pret a installer, faire ENTREE pour poursuivre,  CTRL-C pour arreter =>"



echo "Installation debute pwd= $PWD"
echo "Installation de la version $IZLITEVERSION"
echo "           dans $NEWCHEMIN"

# ------- copie de la matiere logicielle ------------------

mkdir -p $NEWCHEMIN
mkdir -p $NEWCHEMIN/data

cp   ./target/${BIGJARNAME} $NEWCHEMIN/izlite-bigjar.jar
COPIE1=$?
if [ "$COPIE1" = "0" ]; then
    echo "Copie du JAR  OK" 
else
 echo "Copie duJAR ${BIGJARNAME} impossible vers  $NEWCHEMIN"
 exit 20
fi

# ------- copie du script de boot IHM ------------------

cp ./izliteboot2025.sh  $NEWCHEMIN
COPIE2=$?
if [ "$COPIE2" = "0" ]; then
    echo "Copie du script izliteboot2025.sh OK"
else
 echo "Copie izliteboot2025.sh impossible vers  $NEWCHEMIN"
 exit 21
fi

# ------- copie du script de boot deporte ------------------

cp ./izldeport2025.sh  $NEWCHEMIN
COPIE2=$?
if [ "$COPIE2" = "0" ]; then
    echo "Copie du script izldeport2025.sh OK"
else
 echo "Copie izldeport2025.sh impossible vers  $NEWCHEMIN"
 exit 21
fi

# -------- autorisation d'execution -------------

chmod -R +rx $NEWCHEMIN

# --------- Install de la base des fixtures et autres data-------------------

echo "Installation des donnees dans $NEWCHEMIN/data/"
cp -R ./data/*   $NEWCHEMIN/data/
COPIE_DATA=$?
if [ "$COPIE_DATA" = "0" ]; then
    echo "Copie des donnees OK"
else
 echo "ECHEC INSTALLATION DES DONNEES vers $NEWCHEMIN/data/"
 exit 23
fi

# ---------- et on fait pointer /opt/izlite vers cette nouvelle version

cd $DEST

if [ -L $APPLICATION ]; then
   echo "Suppression de l'ancien lien symbolique"
   rm $APPLICATION
fi

echo "Creation du lien symbolique ${DEST}/$APPLICATIONl pointant sur $NEWVERSION"

ln -s $NEWVERSION $APPLICATION

# raccourci a usage temporaire pour verifier
alias izlite="$NEWCHEMIN/izliteboot2025.sh"

echo "Installation version $IZLITEVERSION terminee dans $NEWCHEMIN"

